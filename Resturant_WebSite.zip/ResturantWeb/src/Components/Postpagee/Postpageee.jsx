import './Postpageee.css'

const Postpageee = () => {
  return (
    <div className='noooo'>
     <p>2022</p><hr />
      <div className="Newcard">
        <div className="card " id="OnE">
          <div className="card-body">
Dining with a View: A Tour of Our Renovated Patio
            <h6 className="date">This is some text inside of a div block.
</h6>
          </div>
        </div>
        <div className="card " id="OnE">
          <div className="card-body">
          From Farm to Table: Our Commitment to Sustainable Sourcing
            <h6 className="date">This is some text inside of a div block.</h6>
          </div>
        </div>
        {/* <div className="card " id="OnE">
          <div className="card-body">
            Meet Ascent's New Chef - Julian Kennedy.
            <h6 className="date">February 29, 2024</h6>
          </div>
        </div> */}
      </div>
    </div>
  )
}

export default Postpageee
