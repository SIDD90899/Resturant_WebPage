import './Footer.css'

const Footer = () => {
  return (
    <div className="footer">
    <p>&copy; 2024 WelCome To Ascent</p>
  </div>
  )
}

export default Footer
