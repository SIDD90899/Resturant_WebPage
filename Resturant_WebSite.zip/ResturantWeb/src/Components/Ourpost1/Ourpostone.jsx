import './Ourpostone.css'

const Ourpostone = () => {
  return (
    <div className='container'>
      <div className='container-left'>
        <h4>OUR STORY</h4>
      </div>
      <div className='container-right'>
        <div className='container-right-top'>
       <h2>
       Discover the essence <br />of fresh food and spec
       </h2>
        </div>
        <div className='container-right-down'>
        <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum.
        </p>
        </div>
      </div>
    </div>
  )
}

export default Ourpostone;
