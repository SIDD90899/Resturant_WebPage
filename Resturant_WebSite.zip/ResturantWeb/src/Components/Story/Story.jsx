
const Story = () => {
    
  return (
    <div className="container-fluid">
        <div>

        </div>
    </div>
  )
}

export default Story
