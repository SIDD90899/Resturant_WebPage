import Pstpage2 from '../Postpage/Pstpage2'
import Postpageee from '../Postpagee/Postpageee'
import './Postpage1.css'

const Postpage1 = () => {
  return (
    <div className='' id='postuuuu'>
   <div className="">
    <h1 className="display-1" id="postt">Posts</h1>
    <p className="paruu">The latest of the Ascent blog</p>
</div>
      <Pstpage2/>
      <Postpageee />
    </div>
  )
}

export default Postpage1
