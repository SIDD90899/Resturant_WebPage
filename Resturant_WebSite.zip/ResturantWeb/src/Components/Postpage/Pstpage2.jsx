import "./Postpage2.css";

const Pstpage2 = () => {
  return (
    <div className="container-fluid" id="">
      <p>2023</p><hr />
      <div className="Newcard">
        <div className="card " id="OnE">
          <div className="card-body">
            Meet Our Culinary Team: Passion for Food, Love for Cooking
            <h6 className="date">June 21, 2023</h6>
          </div>
        </div>
        <div className="card " id="OnE">
          <div className="card-body" id="Card-bbb">
            Seasonal Delights: Exploring Our Spring Menu
            <h6 className="date">December 14, 2023</h6>
          </div>
        </div>
        <div className="card " id="OnE">
          <div className="card-body">
            Meet Ascent's New Chef - Julian Kennedy.
            <h6 className="date">February 29, 2024</h6>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pstpage2;
